<head>
	<meta charset="UTF-8">
	<script src='js/jquery.min.js'></script>
	<script src='js/fx.js'></script>
	
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link href='http://fonts.googleapis.com/css?family=Patua+One|Roboto+Slab' rel='stylesheet' type='text/css'>

	
	<link rel="apple-touch-icon" href="touchicon.png">
	<link rel="icon" href="favicon.png">
	<!--[if IE]><link rel="shortcut icon" href="favicon.ico"><![endif]-->
	<!-- or, set /favicon.ico for IE10 win -->
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="tileicon.png">


	<title>Transmt Bulk Messaging</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" > 
	
</head>