
		<div class="footer">
			<h1>Contact Us</h1>
			<!-- <p><a href="http://blog.transmt.com.ng"><span class="icon-book"></span>The Official Transmt Blog</a></p> -->
			<p><a href="mailto:someone@example.com?Subject=Coming%20Soon" target="_top"> <span class="icon-envelop"></span>eMail Us</a></p>
			<!-- <p><a href="https://www.facebook.com/pages/Transmt/398265986965469"><span class="icon-facebook"></span>Transmt Bulk Messaging</a></p> -->
			<p><a href="https://twitter.com/transmtapp"><span class="icon-twitter"></span>TransmtApp on Twitter</a></p>
		<!-- 	<p><span class="icon-google-plus"></span>Google+</p> -->
			<p>&copy; <?php echo date("Y");?> <a href="http://www.transmt.com.ng">Transmt</a></p>
		</div>